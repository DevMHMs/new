echo "    【AntiAlpha】   "
echo "By 👑 DevMHM 👑
echo "Channel 👑 @AntiAlpha 👑
By 👑 DevMHM 👑
echo "ID 👑 @DevAllein 👑